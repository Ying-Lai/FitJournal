package com.gmail.plai2.ying.fitjournal.ui2.exercises;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class StrengthInfoViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public StrengthInfoViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is exercise" +
                " fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}