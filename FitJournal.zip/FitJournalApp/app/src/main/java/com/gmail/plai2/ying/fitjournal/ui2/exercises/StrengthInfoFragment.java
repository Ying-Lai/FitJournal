package com.gmail.plai2.ying.fitjournal.ui2.exercises;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.gmail.plai2.ying.fitjournal.R;

public class StrengthInfoFragment extends Fragment {

    private StrengthInfoViewModel strengthInfoViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        strengthInfoViewModel =
                ViewModelProviders.of(this).get(StrengthInfoViewModel.class);
        View root = inflater.inflate(R.layout.fragment_cardio_info, container, false);
        return root;
    }
}