package com.gmail.plai2.ying.fitjournal.ui.calendar;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import com.gmail.plai2.ying.fitjournal.R;
import com.gmail.plai2.ying.fitjournal.SelectedDayActivity;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;
import com.prolificinteractive.materialcalendarview.format.DateFormatTitleFormatter;
import com.prolificinteractive.materialcalendarview.format.TitleFormatter;

import java.text.DateFormat;

public class CalendarHomeFragment extends Fragment {

    private CalendarHomeViewModel calendarHomeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
            ViewGroup container, Bundle savedInstanceState) {
        calendarHomeViewModel =
                ViewModelProviders.of(this).get(CalendarHomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_calendar, container, false);

        final MaterialCalendarView calendar = root.findViewById(R.id.calendarView);
        calendar.setSelectionMode(MaterialCalendarView.SELECTION_MODE_SINGLE);
        calendar.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
                Intent startSelectedDateActivity = new Intent(getContext(), SelectedDayActivity.class);
                //pass in the date
                startActivity(startSelectedDateActivity);
            }
        });
        return root;
    }
}