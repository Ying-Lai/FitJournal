package com.gmail.plai2.ying.fitjournal.ui2.exercises;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.gmail.plai2.ying.fitjournal.R;

import java.util.List;

public class ExerciseCardAdaptor extends RecyclerView.Adapter<ExerciseCardAdaptor.ViewHolder> {

    List<ExerciseCard> ExerciseCardList;
    Context context;

    public ExerciseCardAdaptor(List<ExerciseCard> exerciseCardList)
    {
        this.ExerciseCardList = exerciseCardList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise_item,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        context = parent.getContext();
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        ExerciseCard exerciseCard = ExerciseCardList.get(position);

        holder.textExercise.setText(exerciseCard.getExerciseName());
        holder.imgExercise.setImageResource(exerciseCard.getImgName());
        holder.cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"The position is:"+position,Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return ExerciseCardList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        ImageView imgExercise;
        TextView textExercise;
        CardView cv;

        public ViewHolder(View itemView)
        {
            super(itemView);
            imgExercise = (ImageView)itemView.findViewById(R.id.imgWorkout);
            textExercise = (TextView)itemView.findViewById(R.id.textWorkout);
            cv = itemView.findViewById(R.id.cv);
        }

    }
}
