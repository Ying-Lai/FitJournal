package com.gmail.plai2.ying.fitjournal.ui2.exercises;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class CardioInfoViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public CardioInfoViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is exercise" +
                " fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}