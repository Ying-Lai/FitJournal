package com.gmail.plai2.ying.fitjournal.ui2.measurements;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.gmail.plai2.ying.fitjournal.R;
import com.gmail.plai2.ying.fitjournal.SelectedDayActivity;

public class MeasurementsFragment extends Fragment {

    private MeasurementsViewModel measurementsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        measurementsViewModel =
                ViewModelProviders.of(this).get(MeasurementsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_measurements, container, false);
        return root;
    }
}