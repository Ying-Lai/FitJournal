package com.gmail.plai2.ying.fitjournal.ui2.exercises;

public class ExerciseCard {
    private String exerciseName;
    private int imgName;

    public String getExerciseName() {
        return exerciseName;
    }
    public void setTvshow(String exerciseName) {
        this.exerciseName = exerciseName;
    }
    public int getImgName() {
        return imgName;
    }
    public void setImgName(int imgName) {
        this.imgName = imgName;
    }
}
